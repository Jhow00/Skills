
package sistema.escolar;


public class Turma {
    // Atributos
    private int sala;
    private String turno;
    private int totAluno;
    
    // Metodos especiais

    public int getSala() {
        return sala;
    }

    public void setSala(int sala) {
        this.sala = sala;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public int getTotAluno() {
        return totAluno;
    }

    public void setTotAluno(int totAluno) {
        this.totAluno = totAluno;
    }
    
    
}
