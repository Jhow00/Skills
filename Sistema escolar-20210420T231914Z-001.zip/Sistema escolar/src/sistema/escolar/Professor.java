
package sistema.escolar;

public class Professor {
    // Atributos
    private Disciplina leciona;

    
    // Metodos especiais
    public Disciplina getLeciona() {
        return leciona;
    }

    public void setLeciona(Disciplina leciona) {
        this.leciona = leciona;
    }
    
    
}
