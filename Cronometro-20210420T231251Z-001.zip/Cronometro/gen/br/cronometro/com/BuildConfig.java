/** Automatically generated file. DO NOT MODIFY */
package br.cronometro.com;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}